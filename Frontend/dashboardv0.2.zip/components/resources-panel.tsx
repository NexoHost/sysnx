"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertTriangle, Cpu, HardDrive, Activity, Clock, Download, Server } from "lucide-react"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts"

interface NexoHostResourceData {
  cpu: number
  memory: number
  disk: number
  uptime: string
  hardware?: {
    cores: number
    totalRam: string
    usedRam: string
    totalDisk: string
    usedDisk: string
  }
}

interface NexoHostResourcesPanelProps {
  apiUrl: string
  wsData: any
}

const nexohostConvertMBtoGB = (mb: string): string => {
  const mbValue = Number.parseFloat(mb)
  if (isNaN(mbValue)) return mb
  return (mbValue / 1024).toFixed(2)
}

export default function ResourcesPanel({ apiUrl, wsData }: NexoHostResourcesPanelProps) {
  const [nexohostResources, setNexohostResources] = useState<NexoHostResourceData | null>(null)
  const [nexohostLoading, setNexohostLoading] = useState(false)
  const [nexohostInitialLoad, setNexohostInitialLoad] = useState(true)
  const [nexohostHistory, setNexohostHistory] = useState<
    Array<{ time: string; cpu: number; memory: number; disk: number }>
  >([])
  const nexohostUptimeCache = useRef<string>("")
  const [nexohostDownloadingReport, setNexohostDownloadingReport] = useState(false)
  const fetchTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const nexohostFetchResources = useCallback(async () => {
    setNexohostLoading(true)
    try {
      const response = await fetch(`${apiUrl}/resources`, { signal: AbortSignal.timeout(5000) })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.uptime && data.uptime !== "N/A") {
        nexohostUptimeCache.current = data.uptime
      }

      const nexohostDisplayData = {
        ...data,
        uptime: data.uptime && data.uptime !== "N/A" ? data.uptime : nexohostUptimeCache.current || "N/A",
      }

      setNexohostResources(nexohostDisplayData)
      setNexohostInitialLoad(false)

      const now = new Date().toLocaleTimeString()
      setNexohostHistory((prev) => [
        ...prev.slice(-11),
        { time: now, cpu: data.cpu, memory: data.memory, disk: data.disk },
      ])
    } catch (error) {
      console.error("[NexoHost] Error fetching resources:", error)
    } finally {
      setNexohostLoading(false)
    }
  }, [apiUrl])

  useEffect(() => {
    nexohostFetchResources()
    const nexohostInterval = setInterval(nexohostFetchResources, 3000)
    return () => {
      clearInterval(nexohostInterval)
      if (fetchTimeoutRef.current) clearTimeout(fetchTimeoutRef.current)
    }
  }, [apiUrl, nexohostFetchResources])

  useEffect(() => {
    if (wsData?.type === "resources") {
      if (wsData.data.uptime && wsData.data.uptime !== "N/A") {
        nexohostUptimeCache.current = wsData.data.uptime
      }

      const nexohostDisplayData = {
        ...wsData.data,
        uptime:
          wsData.data.uptime && wsData.data.uptime !== "N/A"
            ? wsData.data.uptime
            : nexohostUptimeCache.current || "N/A",
      }

      setNexohostResources(nexohostDisplayData)
      setNexohostInitialLoad(false)
      const now = new Date().toLocaleTimeString()
      setNexohostHistory((prev) => [
        ...prev.slice(-11),
        {
          time: now,
          cpu: wsData.data.cpu,
          memory: wsData.data.memory,
          disk: wsData.data.disk,
        },
      ])
    }
  }, [wsData])

  const nexohostDownloadReport = useCallback(async () => {
    setNexohostDownloadingReport(true)
    try {
      const [resourcesRes, processesRes, networkRes, cronRes] = await Promise.all([
        fetch(`${apiUrl}/resources`),
        fetch(`${apiUrl}/processes`),
        fetch(`${apiUrl}/network`),
        fetch(`${apiUrl}/cron`),
      ])

      const resourcesData = await resourcesRes.json()
      const processesData = await processesRes.json()
      const networkData = await networkRes.json()
      const cronData = await cronRes.json()

      const nexohostReportContent = `
===========================================
REPORTE DEL SISTEMA VPS - NEXOHOST
Generado: ${new Date().toLocaleString()}
Powered by NexoHost Development
===========================================

RECURSOS ACTUALES
-----------------
CPU: ${resourcesData.cpu}%
Memoria: ${resourcesData.memory}%
Disco: ${resourcesData.disk}%
Uptime: ${resourcesData.uptime}

HARDWARE DEL SISTEMA
--------------------
Núcleos de CPU: ${resourcesData.hardware?.cores || "N/A"}
RAM Total: ${nexohostConvertMBtoGB(resourcesData.hardware?.totalRam || "0")} GB
RAM Usada: ${nexohostConvertMBtoGB(resourcesData.hardware?.usedRam || "0")} GB
Disco Total: ${resourcesData.hardware?.totalDisk || "N/A"}
Disco Usado: ${nexohostConvertMBtoGB(resourcesData.hardware?.usedDisk || "N/A")}

HISTÓRICO DE RECURSOS (últimos ${nexohostHistory.length} registros)
-----------------
${nexohostHistory.map((h) => `${h.time} - CPU: ${h.cpu}%, RAM: ${h.memory}%, Disco: ${h.disk}%`).join("\n")}

PROCESOS DEL SISTEMA
--------------------
${processesData.data}

INFORMACIÓN DE RED
------------------
${networkData.data}

TAREAS CRON
-----------
${cronData.data}

===========================================
© NexoHost Development - Sistema de Monitoreo VPS
===========================================
      `.trim()

      const blob = new Blob([nexohostReportContent], { type: "text/plain" })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `nexohost-vps-report-${new Date().toISOString().split("T")[0]}.txt`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("[NexoHost] Error generating report:", error)
      alert("Error al generar el reporte. Verifica que el servidor esté disponible.")
    } finally {
      setNexohostDownloadingReport(false)
    }
  }, [apiUrl, nexohostHistory])

  const nexohostGetStatusColor = (value: number) => {
    if (value >= 80) return "text-red-500"
    if (value >= 60) return "text-yellow-500"
    return "text-green-500"
  }

  const nexohostGetStatusBadge = (value: number) => {
    if (value >= 80) return <Badge variant="destructive">Alto</Badge>
    if (value >= 60)
      return (
        <Badge variant="outline" className="border-yellow-500 text-yellow-500">
          Medio
        </Badge>
      )
    return (
      <Badge variant="outline" className="border-green-500 text-green-500">
        Normal
      </Badge>
    )
  }

  if (!nexohostResources && nexohostInitialLoad) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!nexohostResources) {
    return (
      <Card className="border-red-500/50 bg-red-500/10">
        <CardContent className="flex flex-col items-center justify-center gap-4 py-12">
          <AlertTriangle className="h-12 w-12 text-red-500" />
          <div className="text-center space-y-2">
            <p className="text-lg font-semibold">Error al conectar con el servidor</p>
            <p className="text-sm text-muted-foreground">El backend no está corriendo o no es accesible</p>
            <div className="text-xs text-muted-foreground bg-muted p-3 rounded-md mt-4 text-left max-w-md">
              <p className="font-semibold mb-2">Para solucionar:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Asegúrate de que el backend esté corriendo</li>
                <li>
                  Ejecuta: <code className="bg-background px-1 py-0.5 rounded">node server.js</code>
                </li>
                <li>Verifica que los puertos 4040 y 4041 estén abiertos</li>
                <li>Revisa el README.md para más información</li>
              </ol>
            </div>
          </div>
          <Button onClick={() => nexohostFetchResources()} disabled={nexohostLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${nexohostLoading ? "animate-spin" : ""}`} />
            Reintentar Conexión
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {(nexohostResources.cpu >= 80 || nexohostResources.memory >= 80 || nexohostResources.disk >= 80) && (
        <Card className="border-yellow-500/50 bg-yellow-500/10">
          <CardContent className="flex items-center gap-2 py-3">
            <AlertTriangle className="h-5 w-5 text-yellow-500" />
            <p className="text-sm font-medium">Alerta: Recursos del sistema por encima del 80%</p>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {/* CPU Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-blue-500" />
                <span className="text-sm font-medium">CPU</span>
              </div>
              {nexohostGetStatusBadge(nexohostResources.cpu)}
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl font-bold ${nexohostGetStatusColor(nexohostResources.cpu)}`}>
                  {nexohostResources.cpu.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground">%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all will-change-[width] ${
                    nexohostResources.cpu >= 80
                      ? "bg-red-500"
                      : nexohostResources.cpu >= 60
                        ? "bg-yellow-500"
                        : "bg-blue-500"
                  }`}
                  style={{ width: `${nexohostResources.cpu}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* RAM Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-green-500" />
                <span className="text-sm font-medium">RAM</span>
              </div>
              {nexohostGetStatusBadge(nexohostResources.memory)}
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl font-bold ${nexohostGetStatusColor(nexohostResources.memory)}`}>
                  {nexohostResources.memory.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground">%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all will-change-[width] ${
                    nexohostResources.memory >= 80
                      ? "bg-red-500"
                      : nexohostResources.memory >= 60
                        ? "bg-yellow-500"
                        : "bg-green-500"
                  }`}
                  style={{ width: `${nexohostResources.memory}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Disco Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <HardDrive className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-medium">Disco</span>
              </div>
              {nexohostGetStatusBadge(nexohostResources.disk)}
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl font-bold ${nexohostGetStatusColor(nexohostResources.disk)}`}>
                  {nexohostResources.disk.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground">%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all will-change-[width] ${
                    nexohostResources.disk >= 80
                      ? "bg-red-500"
                      : nexohostResources.disk >= 60
                        ? "bg-yellow-500"
                        : "bg-orange-500"
                  }`}
                  style={{ width: `${nexohostResources.disk}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Uptime Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-purple-500" />
                <span className="text-sm font-medium">Uptime</span>
              </div>
              <Button
                onClick={() => nexohostFetchResources()}
                disabled={nexohostLoading}
                size="sm"
                variant="ghost"
                className="h-6 w-6 p-0"
              >
                <RefreshCw className={`h-3 w-3 ${nexohostLoading ? "animate-spin" : ""}`} />
              </Button>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                <span className="font-mono text-sm font-medium">{nexohostResources.uptime}</span>
              </div>
              <p className="text-xs text-muted-foreground">Tiempo activo</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {nexohostResources.hardware && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="h-5 w-5 text-primary" />
                <CardTitle className="text-base">Especificaciones del Hardware</CardTitle>
              </div>
              <Button onClick={nexohostDownloadReport} disabled={nexohostDownloadingReport} size="sm" variant="outline">
                <Download className={`h-4 w-4 mr-2 ${nexohostDownloadingReport ? "animate-bounce" : ""}`} />
                Descargar Reporte
              </Button>
            </div>
            <CardDescription className="text-xs">Recursos totales del sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                <span className="text-xs text-muted-foreground">Núcleos CPU</span>
                <span className="text-lg font-bold text-blue-500">{nexohostResources.hardware.cores}</span>
              </div>
              <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                <span className="text-xs text-muted-foreground">RAM Total</span>
                <span className="text-lg font-bold text-green-500">
                  {nexohostConvertMBtoGB(nexohostResources.hardware.totalRam)} GB
                </span>
              </div>
              <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                <span className="text-xs text-muted-foreground">RAM Usada</span>
                <span className="text-lg font-bold text-green-600">
                  {nexohostConvertMBtoGB(nexohostResources.hardware.usedRam)} GB
                </span>
              </div>
              <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                <span className="text-xs text-muted-foreground">Disco Total</span>
                <span className="text-lg font-bold text-orange-500 break-all">
                  {nexohostResources.hardware.totalDisk}
                </span>
              </div>
              <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                <span className="text-xs text-muted-foreground">Disco Usado</span>
                <span className="text-lg font-bold text-orange-600 break-all">
                  {nexohostConvertMBtoGB(nexohostResources.hardware.usedDisk)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Uso de CPU y Memoria</CardTitle>
            <CardDescription className="text-xs">Histórico de los últimos minutos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={nexohostHistory}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="time" className="text-xs" tick={{ fontSize: 10 }} />
                  <YAxis className="text-xs" tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--background))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "0.5rem",
                      padding: "0.5rem",
                      fontSize: "0.75rem",
                    }}
                    formatter={(value: any) => `${value.toFixed(1)}%`}
                    labelFormatter={(label) => `${label}`}
                  />
                  <Line
                    type="monotone"
                    dataKey="cpu"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    dot={false}
                    name="CPU"
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="memory"
                    stroke="#10b981"
                    strokeWidth={3}
                    dot={false}
                    name="Memoria"
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Uso de Disco</CardTitle>
            <CardDescription className="text-xs">Tendencia de almacenamiento</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={nexohostHistory}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="time" className="text-xs" tick={{ fontSize: 10 }} />
                  <YAxis className="text-xs" tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--background))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "0.5rem",
                      padding: "0.5rem",
                      fontSize: "0.75rem",
                    }}
                    formatter={(value: any) => `${value.toFixed(1)}%`}
                    labelFormatter={(label) => `${label}`}
                  />
                  <Line
                    type="monotone"
                    dataKey="disk"
                    stroke="#f97316"
                    strokeWidth={3}
                    dot={false}
                    name="Disco"
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
