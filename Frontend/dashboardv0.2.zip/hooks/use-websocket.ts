"use client"

import { useEffect, useState, useRef, useCallback } from "react"

export function useWebSocket(url: string | null) {
  const [data, setData] = useState<any>(null)
  const [isConnected, setIsConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const connectWebSocket = useCallback(() => {
    if (!url) return

    try {
      const ws = new WebSocket(url)
      wsRef.current = ws

      ws.onopen = () => {
        console.log("[NexoHost] WebSocket conectado")
        setIsConnected(true)
      }

      ws.onmessage = (event) => {
        try {
          const parsedData = JSON.parse(event.data)
          setData(parsedData)
        } catch (error) {
          console.error("[NexoHost] Error parsing WebSocket:", error)
        }
      }

      ws.onerror = (error) => {
        console.error("[NexoHost] WebSocket error:", error)
        setIsConnected(false)
      }

      ws.onclose = () => {
        setIsConnected(false)
        reconnectTimeoutRef.current = setTimeout(() => {
          if (wsRef.current?.readyState === WebSocket.CLOSED) {
            connectWebSocket()
          }
        }, 10000)
      }
    } catch (error) {
      console.error("[NexoHost] Error creating WebSocket:", error)
      setIsConnected(false)
    }
  }, [url])

  useEffect(() => {
    connectWebSocket()

    return () => {
      if (wsRef.current) {
        wsRef.current.close()
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
    }
  }, [connectWebSocket])

  return { data, isConnected }
}
