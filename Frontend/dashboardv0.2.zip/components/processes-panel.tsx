"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { RefreshCw, Search, XCircle, AlertTriangle, AlertCircle, Loader } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface NexoHostProcessesPanelProps {
  apiUrl: string
}

interface NexoHostProcess {
  pid: string
  ppid: string
  user: string
  cpu: number
  memory: number
  command: string
}

export default function ProcessesPanel({ apiUrl }: NexoHostProcessesPanelProps) {
  const [nexohostProcesses, setNexohostProcesses] = useState<NexoHostProcess[]>([])
  const [nexohostLoading, setNexohostLoading] = useState(true)
  const [nexohostError, setNexohostError] = useState<string | null>(null)
  const [nexohostSearchTerm, setNexohostSearchTerm] = useState("")
  const [nexohostKillingPid, setNexohostKillingPid] = useState<string | null>(null)

  const nexohostFetchProcesses = async () => {
    setNexohostLoading(true)
    setNexohostError(null)

    try {
      const response = await fetch(`${apiUrl}/processes/json`, {
        signal: AbortSignal.timeout(5000),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`)
      }

      const data = await response.json()
      setNexohostProcesses(data.processes || [])
      setNexohostError(null)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Error desconocido"
      console.error("[NexoHost] Error fetching processes:", errorMessage)

      setNexohostError(
        apiUrl.includes("localhost")
          ? `No se puede conectar a ${apiUrl}. Por favor, asegúrate de que el backend está ejecutándose.`
          : `No se puede conectar al servidor. Verifica la conexión de red.`,
      )
      setNexohostProcesses([])
    } finally {
      setNexohostLoading(false)
    }
  }

  const nexohostKillProcess = async (pid: string, signal = "TERM") => {
    if (!confirm(`¿Estás seguro de que quieres detener el proceso ${pid}?`)) {
      return
    }

    setNexohostKillingPid(pid)
    try {
      const response = await fetch(`${apiUrl}/processes/kill`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ pid, signal }),
      })

      const data = await response.json()

      if (response.ok && data.success) {
        alert(`Proceso ${pid} detenido exitosamente`)
        nexohostFetchProcesses()
      } else {
        alert(`Error: ${data.error || "No se pudo detener el proceso"}`)
      }
    } catch (error) {
      console.error("[NexoHost] Error killing process:", error)
      alert("Error al intentar detener el proceso")
    } finally {
      setNexohostKillingPid(null)
    }
  }

  useEffect(() => {
    nexohostFetchProcesses()
    const nexohostInterval = setInterval(nexohostFetchProcesses, 5000)
    return () => clearInterval(nexohostInterval)
  }, [apiUrl])

  const nexohostFilteredProcesses = nexohostProcesses.filter(
    (proc) =>
      proc.command.toLowerCase().includes(nexohostSearchTerm.toLowerCase()) ||
      proc.user.toLowerCase().includes(nexohostSearchTerm.toLowerCase()) ||
      proc.pid.includes(nexohostSearchTerm),
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Procesos del Sistema</CardTitle>
            <CardDescription>Lista de procesos en ejecución - NexoHost Monitor</CardDescription>
          </div>
          <Button onClick={nexohostFetchProcesses} disabled={nexohostLoading} size="sm">
            <RefreshCw className={`h-4 w-4 mr-2 ${nexohostLoading ? "animate-spin" : ""}`} />
            Actualizar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {nexohostError && (
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium text-destructive">Error de Conexión</p>
                <p className="text-sm text-destructive/80">{nexohostError}</p>
              </div>
            </div>
          )}

          {nexohostLoading && nexohostProcesses.length === 0 && (
            <div className="flex items-center justify-center py-12 gap-2">
              <Loader className="h-5 w-5 animate-spin text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Cargando procesos...</p>
            </div>
          )}

          {!nexohostError && nexohostProcesses.length > 0 && (
            <>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por comando, usuario o PID..."
                  value={nexohostSearchTerm}
                  onChange={(e) => setNexohostSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-muted">
                      <TableRow>
                        <TableHead>PID</TableHead>
                        <TableHead>Usuario</TableHead>
                        <TableHead>CPU%</TableHead>
                        <TableHead>MEM%</TableHead>
                        <TableHead>Comando</TableHead>
                        <TableHead className="text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {nexohostFilteredProcesses.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground">
                            No se encontraron procesos
                          </TableCell>
                        </TableRow>
                      ) : (
                        nexohostFilteredProcesses.map((proc) => (
                          <TableRow key={proc.pid}>
                            <TableCell className="font-mono text-xs">
                              <Badge variant="outline">{proc.pid}</Badge>
                            </TableCell>
                            <TableCell className="font-mono text-xs">{proc.user}</TableCell>
                            <TableCell className="font-mono text-xs">
                              <span className={proc.cpu > 50 ? "text-red-500 font-bold" : ""}>
                                {proc.cpu.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="font-mono text-xs">
                              <span className={proc.memory > 50 ? "text-yellow-500 font-bold" : ""}>
                                {proc.memory.toFixed(1)}%
                              </span>
                            </TableCell>
                            <TableCell className="font-mono text-xs truncate max-w-md" title={proc.command}>
                              {proc.command}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => nexohostKillProcess(proc.pid)}
                                disabled={nexohostKillingPid === proc.pid}
                                className="h-7 px-2"
                              >
                                {nexohostKillingPid === proc.pid ? (
                                  <RefreshCw className="h-3 w-3 animate-spin" />
                                ) : (
                                  <>
                                    <XCircle className="h-3 w-3 mr-1" />
                                    Detener
                                  </>
                                )}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Mostrando {nexohostFilteredProcesses.length} procesos</span>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <span className="text-xs">Detener procesos del sistema puede causar inestabilidad</span>
                </div>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
