"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Send, Trash2, TerminalIcon } from "lucide-react"

interface TerminalPanelProps {
  apiUrl: string
}

interface CommandHistory {
  command: string
  output: string
  timestamp: string
}

export default function TerminalPanel({ apiUrl }: TerminalPanelProps) {
  const [command, setCommand] = useState("")
  const [history, setHistory] = useState<CommandHistory[]>([])
  const [loading, setLoading] = useState(false)
  const outputRef = useRef<HTMLDivElement>(null)

  const quickCommands = [
    { label: "ls -la", command: "ls -la" },
    { label: "df -h", command: "df -h" },
    { label: "free -h", command: "free -h" },
    { label: "top -bn1", command: "top -bn1 | head -20" },
    { label: "netstat", command: "netstat -tuln" },
    { label: "uptime", command: "uptime" },
  ]

  const executeCommand = async (cmd: string) => {
    if (!cmd.trim()) return

    setLoading(true)
    const timestamp = new Date().toLocaleTimeString()

    try {
      const response = await fetch(`${apiUrl}/terminal`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ command: cmd }),
      })
      const data = await response.json()

      setHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: data.output || "Comando ejecutado sin salida",
          timestamp,
        },
      ])
    } catch (error) {
      console.error("[v0] Error executing command:", error)
      setHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: `Error: No se pudo ejecutar el comando\n${error}`,
          timestamp,
        },
      ])
    } finally {
      setLoading(false)
      setCommand("")
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    executeCommand(command)
  }

  const clearHistory = () => {
    setHistory([])
  }

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [history])

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TerminalIcon className="h-5 w-5" />
                Terminal Interactiva
              </CardTitle>
              <CardDescription>Ejecuta comandos en el servidor VPS</CardDescription>
            </div>
            <Button onClick={clearHistory} variant="outline" size="sm">
              <Trash2 className="h-4 w-4 mr-2" />
              Limpiar
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Quick Commands */}
          <div>
            <p className="text-sm font-medium mb-2">Comandos Rápidos</p>
            <div className="flex flex-wrap gap-2">
              {quickCommands.map((cmd, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  onClick={() => executeCommand(cmd.command)}
                  disabled={loading}
                >
                  {cmd.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Terminal Output */}
          <div
            ref={outputRef}
            className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-[400px] overflow-y-auto"
          >
            {history.length === 0 ? (
              <div className="text-muted-foreground">
                <p>Terminal lista. Escribe un comando o usa los comandos rápidos.</p>
                <p className="mt-2">Ejemplo: ls -la, df -h, free -h</p>
              </div>
            ) : (
              history.map((entry, idx) => (
                <div key={idx} className="mb-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-blue-400">$</span>
                    <span className="text-white">{entry.command}</span>
                    <span className="text-gray-500 text-xs ml-auto">{entry.timestamp}</span>
                  </div>
                  <pre className="whitespace-pre-wrap text-green-400 ml-4">{entry.output}</pre>
                </div>
              ))
            )}
            {loading && (
              <div className="flex items-center gap-2">
                <span className="text-blue-400">$</span>
                <span className="text-white">{command}</span>
                <span className="animate-pulse">_</span>
              </div>
            )}
          </div>

          {/* Command Input */}
          <form onSubmit={handleSubmit} className="flex gap-2">
            <div className="flex-1 relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">$</span>
              <Input
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                placeholder="Escribe un comando..."
                disabled={loading}
                className="pl-8 font-mono"
              />
            </div>
            <Button type="submit" disabled={loading || !command.trim()}>
              <Send className="h-4 w-4 mr-2" />
              Ejecutar
            </Button>
          </form>

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="outline" className="text-xs">
              Tip
            </Badge>
            <span>Usa comandos como ls, pwd, cat, grep, etc. Evita comandos interactivos.</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
