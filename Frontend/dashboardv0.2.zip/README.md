# Dashboard de Monitoreo VPS

Dashboard moderno y responsive para monitorear recursos de tu VPS en tiempo real.

## Características

- Monitoreo en tiempo real de CPU, RAM, Disco y Uptime
- Gráficos históricos de recursos
- Gestión de procesos del sistema
- Información de red (ifconfig)
- Gestión de tareas Cron
- Terminal interactiva
- Descarga de reportes completos del sistema
- Tema oscuro/claro
- Actualizaciones vía WebSocket

## Requisitos

- Node.js 18+ 
- npm o yarn
- Sistema operativo Linux (Ubuntu, Debian, CentOS, etc.)

## Instalación

### 1. Clonar o descargar el proyecto

\`\`\`bash
cd /var/www2/herramientas/vps
\`\`\`

### 2. Instalar dependencias del backend

\`\`\`bash
npm install express cors ws
\`\`\`

### 3. Instalar dependencias del frontend

\`\`\`bash
cd frontend  # o la carpeta donde esté el frontend
npm install
\`\`\`

### 4. Construir el frontend

\`\`\`bash
npm run build
\`\`\`

Esto generará los archivos estáticos en `dist/`, `build/` o `out/` dependiendo del framework.

### 5. Ejecutar el backend

Desde la carpeta raíz del proyecto:

\`\`\`bash
node server.js
\`\`\`

O con PM2 para mantenerlo corriendo:

\`\`\`bash
npm install -g pm2
pm2 start server.js --name vps-dashboard
pm2 save
pm2 startup
\`\`\`

El servidor estará disponible en:
- API REST: `http://tu-ip:4040`
- WebSocket: `ws://tu-ip:4041`
- Frontend: `http://tu-ip:4040` (servido por Express)

## Configuración

### Variables de entorno (opcional)

Puedes configurar los puertos creando un archivo `.env`:

\`\`\`bash
PORT=4040
WS_PORT=4041
\`\`\`

### Acceso desde el exterior

Si quieres acceder desde fuera del servidor, asegúrate de:

1. Abrir los puertos en el firewall:
\`\`\`bash
sudo ufw allow 4040
sudo ufw allow 4041
\`\`\`

2. Configurar Nginx como proxy reverso (recomendado):

\`\`\`nginx
server {
    listen 80;
    server_name tu-dominio.com;

    location / {
        proxy_pass http://localhost:4040;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /ws {
        proxy_pass http://localhost:4041;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
    }
}
\`\`\`

## Estructura del Proyecto

\`\`\`
vps-dashboard/
├── server.js           # Backend Express + WebSocket
├── frontend/           # Código del frontend
│   ├── app/           # Páginas Next.js
│   ├── components/    # Componentes React
│   └── ...
├── package.json
└── README.md
\`\`\`

## API Endpoints

- `GET /resources` - Recursos del sistema (CPU, RAM, Disco, Uptime)
- `GET /processes` - Lista de procesos
- `GET /network` - Información de red
- `GET /cron` - Tareas cron
- `POST /terminal` - Ejecutar comando en terminal
- `GET /terminal/pwd` - Directorio actual de la terminal
- WebSocket en puerto 4041 - Actualizaciones en tiempo real

## Solución de Problemas

### Error: "Failed to fetch"

El backend no está corriendo. Ejecuta:
\`\`\`bash
node server.js
\`\`\`

### Error: "EADDRINUSE"

El puerto ya está en uso. Cambia el puerto o detén el proceso:
\`\`\`bash
lsof -ti:4040 | xargs kill -9
\`\`\`

### Permisos insuficientes

Algunos comandos requieren permisos de root. Ejecuta el servidor con sudo o configura los permisos adecuados.

### WebSocket no conecta

Verifica que el puerto 4041 esté abierto y que no haya firewall bloqueándolo.

## Desarrollo

Para desarrollo local:

1. Ejecuta el backend:
\`\`\`bash
node server.js
\`\`\`

2. En otra terminal, ejecuta el frontend en modo desarrollo:
\`\`\`bash
cd frontend
npm run dev
\`\`\`

3. Accede a `http://localhost:3000` (frontend) que se conectará a `http://localhost:4040` (backend)

## Licencia

MIT
