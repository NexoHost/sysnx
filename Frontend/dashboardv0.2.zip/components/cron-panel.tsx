"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Clock, Calendar } from "lucide-react"

interface CronPanelProps {
  apiUrl: string
}

export default function CronPanel({ apiUrl }: CronPanelProps) {
  const [cronData, setCronData] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const fetchCron = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${apiUrl}/cron`)
      const data = await response.json()
      setCronData(data.data)
    } catch (error) {
      console.error("[v0] Error fetching cron:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCron()
  }, [apiUrl])

  const parseCronJobs = () => {
    if (!cronData) return []

    const lines = cronData.split("\n").filter((line) => line.trim() && !line.trim().startsWith("#"))

    return lines
      .map((line, idx) => {
        const parts = line.trim().split(/\s+/)
        if (parts.length < 6) return null

        return {
          id: idx,
          minute: parts[0],
          hour: parts[1],
          day: parts[2],
          month: parts[3],
          weekday: parts[4],
          command: parts.slice(5).join(" "),
        }
      })
      .filter(Boolean)
  }

  const cronJobs = parseCronJobs()

  const formatSchedule = (job: any) => {
    const parts = []

    if (job.minute === "*") parts.push("cada minuto")
    else if (job.minute.includes("/")) parts.push(`cada ${job.minute.split("/")[1]} minutos`)
    else parts.push(`minuto ${job.minute}`)

    if (job.hour === "*") parts.push("cada hora")
    else if (job.hour.includes("/")) parts.push(`cada ${job.hour.split("/")[1]} horas`)
    else parts.push(`a las ${job.hour}:00`)

    if (job.day !== "*") parts.push(`día ${job.day}`)
    if (job.month !== "*") parts.push(`mes ${job.month}`)
    if (job.weekday !== "*") {
      const days = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]
      parts.push(days[Number.parseInt(job.weekday)] || `día ${job.weekday}`)
    }

    return parts.join(", ")
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Tareas Programadas (Cron)</CardTitle>
              <CardDescription>Trabajos cron configurados en el sistema</CardDescription>
            </div>
            <Button onClick={fetchCron} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Actualizar
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {cronJobs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No se encontraron tareas cron configuradas</div>
            ) : (
              cronJobs.map((job: any) => (
                <Card key={job.id}>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">{formatSchedule(job)}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <code className="text-xs bg-muted px-2 py-1 rounded">
                              {job.minute} {job.hour} {job.day} {job.month} {job.weekday}
                            </code>
                          </div>
                        </div>
                        <Badge variant="outline">Activo</Badge>
                      </div>
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Comando</p>
                        <code className="text-sm font-mono">{job.command}</code>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Crontab Completo</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-xs font-mono">
            {cronData || "No hay datos disponibles"}
          </pre>
        </CardContent>
      </Card>
    </div>
  )
}
