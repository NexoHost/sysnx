import { NextResponse } from "next/server"
import { headers } from "next/headers"

export async function GET() {
  const headersList = await headers()

  // Get the host and protocol from headers
  const host = headersList.get("host") || "localhost:3000"
  const proto = headersList.get("x-forwarded-proto") || "http"

  const isSecure = proto === "https"

  // Extract IP/hostname without port
  const hostname = host.split(":")[0]

  console.log("[v0] Config API - Host:", host, "Protocol:", proto, "Secure:", isSecure)

  // Return API and WebSocket URLs using the server's IP
  return NextResponse.json({
    apiUrl: `http://${hostname}:4040`,
    wsUrl: `${isSecure ? "wss" : "ws"}://${hostname}:4041`,
  })
}
