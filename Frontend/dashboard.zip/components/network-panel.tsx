"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Wifi, WifiOff, ArrowDown, ArrowUp, Activity } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface NexoHostNetworkPanelProps {
  apiUrl: string
}

interface NexoHostNetworkStats {
  interfaces: Array<{
    interface: string
    rxBytes: number
    txBytes: number
  }>
  total: {
    rxBytes: number
    txBytes: number
    rxMB: string
    txMB: string
  }
  connections: number
}

interface NexoHostNetworkSpeed {
  download: {
    bytesPerSec: number
    kbps: string
    mbps: string
  }
  upload: {
    bytesPerSec: number
    kbps: string
    mbps: string
  }
  timestamp: string
}

export default function NetworkPanel({ apiUrl }: NexoHostNetworkPanelProps) {
  const [nexohostNetworkData, setNexohostNetworkData] = useState<string>("")
  const [nexohostNetworkStats, setNexohostNetworkStats] = useState<NexoHostNetworkStats | null>(null)
  const [nexohostNetworkSpeed, setNexohostNetworkSpeed] = useState<NexoHostNetworkSpeed | null>(null)
  const [nexohostLoading, setNexohostLoading] = useState(false)

  const nexohostFetchNetwork = async () => {
    setNexohostLoading(true)
    try {
      const networkRes = await fetch(`${apiUrl}/network`)
      const networkData = await networkRes.json()

      setNexohostNetworkData(networkData.data)

      if (networkData.stats) {
        setNexohostNetworkStats(networkData.stats)
      }

      if (networkData.speed) {
        setNexohostNetworkSpeed(networkData.speed)
      }
    } catch (error) {
      console.error("[NexoHost] Error fetching network:", error)
    } finally {
      setNexohostLoading(false)
    }
  }

  useEffect(() => {
    nexohostFetchNetwork()
    const nexohostInterval = setInterval(nexohostFetchNetwork, 5000)
    return () => clearInterval(nexohostInterval)
  }, [apiUrl])

  const nexohostParseNetworkInterfaces = () => {
    if (!nexohostNetworkData) return []

    const interfaces = []
    const lines = nexohostNetworkData.split("\n")
    let currentInterface: any = null

    for (const line of lines) {
      if (line.match(/^\d+:/)) {
        if (currentInterface) {
          interfaces.push(currentInterface)
        }
        const match = line.match(/^\d+:\s+(\w+):.*<(.+)>/)
        if (match) {
          currentInterface = {
            name: match[1],
            flags: match[2].split(","),
            addresses: [],
          }
        }
      } else if (currentInterface && line.trim().startsWith("inet")) {
        const match = line.match(/inet\s+([\d.]+)/)
        if (match) {
          currentInterface.addresses.push(match[1])
        }
      }
    }

    if (currentInterface) {
      interfaces.push(currentInterface)
    }

    return interfaces
  }

  const nexohostInterfaces = nexohostParseNetworkInterfaces()

  return (
    <div className="space-y-4">
      {nexohostNetworkSpeed && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Velocidad de Red en Tiempo Real</CardTitle>
                <CardDescription>Tráfico de red actual - NexoHost Monitor</CardDescription>
              </div>
              <Button onClick={nexohostFetchNetwork} disabled={nexohostLoading} size="sm">
                <RefreshCw className={`h-4 w-4 mr-2 ${nexohostLoading ? "animate-spin" : ""}`} />
                Actualizar
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="border-green-500/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <ArrowDown className="h-5 w-5 text-green-500" />
                      <span className="font-semibold">Descarga</span>
                    </div>
                    <Badge variant="outline" className="border-green-500 text-green-500">
                      <Activity className="h-3 w-3 mr-1" />
                      Activo
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-green-500">{nexohostNetworkSpeed.download.mbps}</span>
                      <span className="text-sm text-muted-foreground">Mbps</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {nexohostNetworkSpeed.download.kbps} Kbps (
                      {nexohostNetworkSpeed.download.bytesPerSec.toLocaleString()} bytes/s)
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-500/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <ArrowUp className="h-5 w-5 text-blue-500" />
                      <span className="font-semibold">Subida</span>
                    </div>
                    <Badge variant="outline" className="border-blue-500 text-blue-500">
                      <Activity className="h-3 w-3 mr-1" />
                      Activo
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-blue-500">{nexohostNetworkSpeed.upload.mbps}</span>
                      <span className="text-sm text-muted-foreground">Mbps</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {nexohostNetworkSpeed.upload.kbps} Kbps (
                      {nexohostNetworkSpeed.upload.bytesPerSec.toLocaleString()} bytes/s)
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      )}

      {nexohostNetworkStats && (
        <Card>
          <CardHeader>
            <CardTitle>Estadísticas de Red</CardTitle>
            <CardDescription>Tráfico total y conexiones activas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                  <span className="text-xs text-muted-foreground">Total Recibido</span>
                  <span className="text-lg font-bold text-green-500">{nexohostNetworkStats.total.rxMB} MB</span>
                </div>
                <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                  <span className="text-xs text-muted-foreground">Total Enviado</span>
                  <span className="text-lg font-bold text-blue-500">{nexohostNetworkStats.total.txMB} MB</span>
                </div>
                <div className="flex flex-col gap-1 p-3 rounded-lg bg-muted/50">
                  <span className="text-xs text-muted-foreground">Conexiones</span>
                  <span className="text-lg font-bold text-purple-500">{nexohostNetworkStats.connections}</span>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Interfaz</TableHead>
                      <TableHead className="text-right">Recibido (MB)</TableHead>
                      <TableHead className="text-right">Enviado (MB)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {nexohostNetworkStats.interfaces.map((iface) => (
                      <TableRow key={iface.interface}>
                        <TableCell className="font-mono font-semibold">{iface.interface}</TableCell>
                        <TableCell className="text-right font-mono text-green-600">
                          {(iface.rxBytes / 1024 / 1024).toFixed(2)} MB
                        </TableCell>
                        <TableCell className="text-right font-mono text-blue-600">
                          {(iface.txBytes / 1024 / 1024).toFixed(2)} MB
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Interfaces de Red</CardTitle>
          <CardDescription>Configuración de red del sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {nexohostInterfaces.map((iface, idx) => {
              const isUp = iface.flags.includes("UP")
              return (
                <Card key={idx}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base font-mono">{iface.name}</CardTitle>
                      {isUp ? (
                        <Wifi className="h-4 w-4 text-green-500" />
                      ) : (
                        <WifiOff className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Estado</p>
                      <div className="flex flex-wrap gap-1">
                        {iface.flags.map((flag: string, i: number) => (
                          <Badge key={i} variant={flag === "UP" ? "default" : "secondary"} className="text-xs">
                            {flag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    {iface.addresses.length > 0 && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-2">Direcciones IP</p>
                        {iface.addresses.map((addr: string, i: number) => (
                          <p key={i} className="font-mono text-sm">
                            {addr}
                          </p>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {nexohostInterfaces.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">No se encontraron interfaces de red</div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
