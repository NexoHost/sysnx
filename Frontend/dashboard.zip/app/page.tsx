"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Moon, Sun, Server, Activity, Network, Clock, TerminalIcon } from "lucide-react"
import { useTheme } from "next-themes"
import ResourcesPanel from "@/components/resources-panel"
import ProcessesPanel from "@/components/processes-panel"
import NetworkPanel from "@/components/network-panel"
import CronPanel from "@/components/cron-panel"
import TerminalPanel from "@/components/terminal-panel"
import { useWebSocket } from "@/hooks/use-websocket"

export default function NexoHostVPSDashboard() {
  const { theme, setTheme } = useTheme()
  const [nexohostMounted, setNexohostMounted] = useState(false)
  const [nexohostApiUrl, setNexohostApiUrl] = useState<string>("")
  const [nexohostWsUrl, setNexohostWsUrl] = useState<string>("")
  const [nexohostConfigLoaded, setNexohostConfigLoaded] = useState(false)

  const { data: nexohostWsData, isConnected: nexohostIsConnected } = useWebSocket(nexohostWsUrl)

  useEffect(() => {
    setNexohostMounted(true)
    fetch("/api/config")
      .then((res) => res.json())
      .then((config) => {
        setNexohostApiUrl(config.apiUrl)
        setNexohostWsUrl(config.wsUrl)
        setNexohostConfigLoaded(true)
      })
      .catch((error) => {
        console.error("[NexoHost] Error loading config:", error)
        setNexohostApiUrl("http://localhost:4040")
        setNexohostWsUrl("ws://localhost:4041")
        setNexohostConfigLoaded(true)
      })
  }, [])

  if (!nexohostMounted || !nexohostConfigLoaded) return null

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <Server className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">NexoHost VPS Monitor</h1>
                <p className="text-xs text-muted-foreground">Sistema de Monitoreo en Tiempo Real</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div
                  className={`h-2 w-2 rounded-full ${nexohostIsConnected ? "bg-green-500" : "bg-red-500"} animate-pulse`}
                />
                <span className="text-sm text-muted-foreground">
                  {nexohostIsConnected ? "Conectado" : "Desconectado"}
                </span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
                {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="resources" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="resources" className="gap-2">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">Recursos</span>
            </TabsTrigger>
            <TabsTrigger value="processes" className="gap-2">
              <Server className="h-4 w-4" />
              <span className="hidden sm:inline">Procesos</span>
            </TabsTrigger>
            <TabsTrigger value="network" className="gap-2">
              <Network className="h-4 w-4" />
              <span className="hidden sm:inline">Red</span>
            </TabsTrigger>
            <TabsTrigger value="cron" className="gap-2">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">Cron</span>
            </TabsTrigger>
            <TabsTrigger value="terminal" className="gap-2">
              <TerminalIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Terminal</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="resources" className="space-y-4">
            <ResourcesPanel apiUrl={nexohostApiUrl} wsData={nexohostWsData} />
          </TabsContent>

          <TabsContent value="processes" className="space-y-4">
            <ProcessesPanel apiUrl={nexohostApiUrl} />
          </TabsContent>

          <TabsContent value="network" className="space-y-4">
            <NetworkPanel apiUrl={nexohostApiUrl} />
          </TabsContent>

          <TabsContent value="cron" className="space-y-4">
            <CronPanel apiUrl={nexohostApiUrl} />
          </TabsContent>

          <TabsContent value="terminal" className="space-y-4">
            <TerminalPanel apiUrl={nexohostApiUrl} />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col items-center justify-center gap-2 text-center">
            <p className="text-sm font-medium">Desarrollado por NexoHost Development</p>
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} NexoHost. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
